/* Name: Vanessa Araujo
 * Section: 9509
 * Instructor: Kyla McMullen
 * Due date: 10/25/16
 * Brief Description: This program allows user to check balance of their account, deposit or withdraw money from their account in different currencies, and withdraw all moneys from their account.
 */
import java.util.Scanner;

public class CurrencyExchange {

	private static double balance = 0;

	public static double getBalance() {
		return balance;
	}

	private static boolean updateBalance(double newBalance) {
		balance = Math.round(newBalance * 100) / 100.0;
		if (balance >= 0) {
			return true;
		} else
			return false;
	}

	public static void main(String[] args) {
		int menu;
		Scanner input = new Scanner(System.in);
		System.out.println("Welcome to Currency Exchange 2.0\n");
		printConversionTable();

		do {
			menu = mainMenuOptionSelector(input);

			if (menu == 1) {
				System.out.println("Your current balance is: " + getBalance() + "\n");
			} else if (menu == 2) {
				int currencyType = currencyMenuOptionSelector(input);
				System.out.println("Please enter the deposit amount:");
				double deposit = input.nextDouble();
				boolean depositStatus = deposit(deposit, currencyType);
				if(depositStatus == true) {
					System.out.println(logTransaction(deposit, currencyType, true));
				} else {
					System.out.println("Logging Error");
				}
			} else if (menu == 3) {
				int currencyType = currencyMenuOptionSelector(input);
				System.out.println("Please enter the withdrawl amount:");
				double withdraw = input.nextDouble();
				boolean withDrawStatus = withdraw(withdraw, currencyType);
				if(withDrawStatus == true) {
					System.out.println(logTransaction(withdraw, currencyType, false));
				} else {
					System.out.println("Logging Error");
				}
				
			} else if (menu == 4) {
				double balance = getBalance(); 
				boolean withDrawStatus = withdraw(balance, 1 );
				System.out.println(logTransaction(balance, 1, false));
				System.out.println("Goodbye");
			} else {
				System.out.println("Invalid input");
			}
		} while (menu != 4);
	}

	public static boolean deposit(double amount, int currencyType) {
		if (amount > 0) {
			double convAmount = convertCurrency(amount, currencyType, true);
			updateBalance( getBalance() + convAmount);
			return true;
		} else {
			return false;
		}
	}

	public static boolean withdraw(double amount, int currencyType) {
		double result = convertCurrency(amount, currencyType, false);
		if ((result > 0) && (result <= getBalance()) ) {
			double newBalance = 0;
			// Requested money to be withdrawn was given in US dollars
			if(currencyType == 1) {
				newBalance = getBalance() - result;
			} else {
				newBalance = getBalance() - result*(1.005);
			}
			updateBalance(newBalance);
			return true;
		} else
			return false;
	}

	public static double convertCurrency(double amount, int currencyType, boolean isConvertToUSD) {
		double result = 0.0;
		if (isConvertToUSD == true) {
			// Converting from foreign to US
			if (currencyType == 1) {
				result = amount / 1;
			} else if (currencyType == 2) {
				result = amount / 0.89;
			} else if (currencyType == 3){
				result = amount / 0.78;
			} else if (currencyType == 4){
				result = amount / 66.53;
			} else if (currencyType == 5){
				result = amount / 1.31;
			} else if (currencyType == 6){
				result = amount / 1.31;
			} else if (currencyType == 7){
				result = amount / 1.37;
			} else if (currencyType == 8){
				result = amount / 0.97;
			} else if (currencyType == 9) {
				result = amount / 4.12;
			} else if (currencyType == 10) {
				result = amount / 101.64;
			} else if (currencyType == 11){
				result = amount / 6.67;
			}
		} else {
			// Converting from US to foreign
			if (currencyType == 1) {
				result = amount * 1;
			} else if (currencyType == 2) {
				result = amount * 0.89;
			} else if (currencyType == 3){
				result = amount * 0.78;
			} else if (currencyType == 4) {
				result = amount * 66.53;
			} else if (currencyType == 5) {
				result = amount * 1.31;
			} else if (currencyType == 6) {
				result = amount * 1.31;
			} else if (currencyType == 7){
				result = amount * 1.37;
			} else if (currencyType == 8){
				result = amount * 0.97;
			} else if (currencyType == 9){
				result = amount * 4.12;
			} else if (currencyType == 10){
				result = amount * 101.64;
			} else if (currencyType == 11){
				result = amount * 6.67;
			}
		}
		return result;
	}

	private static String logTransaction(double amount, int currencyType, boolean isDeposit) {
		String result = "";
		if (isDeposit == true) {
			result = "You sucessfully deposited " + amount + " " + currencyToString(currencyType) + "\n";
		} else {
			result = "You sucessfully withdrew " + amount + " " + currencyToString(currencyType) + "\n";
		}
		return result;
	}

	private static String currencyToString(int currencyType) {
		String ret = "";
		switch (currencyType) {
		case 1:
			ret = "U.S. Dollars";
			break;
		case 2:
			ret = "Euros";
			break;
		case 3: 
			ret = "British Pounds";
			break;
		case 4: 
			ret = "Indian Rupees";
			break;
		case 5:
			ret = "Australian Dollars";
			break;
		case 6: 
			ret = "Canadian Dollars";
			break;
		case 7:
			ret = "Singapore Dollars";
			break;
		case 8: 
			ret = "Swiss Francs";
			break;
		case 9: 
			ret = "Malaysian Ringgits";
			break;
		case 10:
			ret = "Japanese Yen";
			break;
		case 11: 
			ret = "Chinese Renminbi";
			break;
		default:
			ret = "";
			break;
		}
		return ret;
	}

	private static int mainMenuOptionSelector(Scanner input) {
		System.out.println("Please select an option from the list below:");
		System.out.println("1. Check the balance of your account");
		System.out.println("2. Make a deposit");
		System.out.println("3. Withdraw an amount in a specific currency");
		System.out.println("4. End your session (and withdraw all remaining currency in U.S. Dollars)");
		int menuChoice = input.nextInt();

		return menuChoice;
	}

	public static int currencyMenuOptionSelector(Scanner input) {
		int currency = 0;
		do {
			System.out.println("Please select the currency type:");
			System.out.println("1. U.S. Dollars");
			System.out.println("2. Euros");
			System.out.println("3. British Pounds");
			System.out.println("4. Indian Rupees");
			System.out.println("5. Australian Dollars");
			System.out.println("6. Canadian Dollars");
			System.out.println("7. Singapore Dollars");
			System.out.println("8. Swiss Francs");
			System.out.println("9. Malaysian Ringgits");
			System.out.println("10. Japanese Yen");
			System.out.println("11. Chinese Yuan Renminbi");

			currency = input.nextInt();
			
			if( (currency < 1) || (currency > 11) ) {
				System.out.println("Invalid input");
			}
		} while ( (currency < 1) || (currency > 11) );
		return currency;
	}

	private static void printConversionTable() {
		System.out.println("Current rates are as follows:");
		System.out.println("1 - U.S. Dollar - 1.00");
		System.out.println("2 - Euro - 0.89");
		System.out.println("3 - British Pound - 0.78");
		System.out.println("4 - Indian Rupee - 66.53");
		System.out.println("5 - Australian Dollar - 1.31");
		System.out.println("6 - Canadian Dollar - 1.31");
		System.out.println("7 - Signapore Dollar - 1.37");
		System.out.println("8 - Swiss Franc - 0.97");
		System.out.println("9 - Malaysian Ringgit - 4.12");
		System.out.println("10 - Japanese Yen - 101.64");
		System.out.println("11 - Chinese Yuan Renminbi - 6.67\n");
	}

}
