/*
 * Name: VANESSA ARAUJO
 * CLASS SECTION: 9509
 * INSTRUCTOR: BRYAN TAYLOR
 * DUE DATE: 10/12/2016
 * BRIEF DESCRIPTION: Using different methods for purposes of retrieving and calculating information, this code takes input from the user on shapes, and based  on their input gives them mathematical information about the shapes.
 */
import java.util.Scanner;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ShapeMachine {

// MAIN METHOD - INCLUDES PASSWORD AND PRINTS OUT THE MENU
public static void main (String[]args){
	ShapeMachine ShapeMachine; 
	int loginAttempts = 0;
	String d;
	String m;
	String y; 
	Scanner sc = new Scanner(System.in);
	System.out.println("Shape Machine login");



	do {
		System.out.println("What is today's day?");
		d = sc.next();
		
		System.out.println("What is today's month?");
		m = sc.next();
		
		System.out.println("What is today's year?");
		y = sc.next();
		
		//THIS CODE CALCULATES HOW MANY ATTEMPTS ARE LEFT IN THE PASSWORD
		if (isTodayDate(d, m, y) == false) {
			if(loginAttempts+1 == 3){
				System.out.println("#ERROR 3rd invalid login attempt. Terminating program.");
			} else {
				System.out.println("#ERROR Login attempt #" +(loginAttempts+1)+ " Invalid input. Please try again.");
			}
			loginAttempts++;
		} else {
			break; 
		}
	} while (loginAttempts < 3);
	
	// THIS PEICE OF CODE PRINTS OUT THE MENU AND TAKES IN USER INPUT
	if (loginAttempts < 3) {
		String menuChoice;
		boolean exitProgram = false;
		System.out.println("Correct Date. Welcome!");
		do {
			boolean validInput = false;
			String shapeSize = "";
			displayMenu();
			menuChoice = sc.nextLine();
			if (sc.hasNextLine()) {
				sc.nextLine();
			}
			
			if (menuChoice.equals("Exit")) {
				exitProgram = true; 
			} else if (menuChoice.equals("Circles")) {
				validInput = true;
				System.out.print("Circles selected. Please enter the radius:");
				
					do { 
						if (validInput == false){
							System.out.print("#ERROR Negative input. Please input the radius again:");
						}
						shapeSize = sc.next();
						/*if (sc.hasNextLine ());{
							sc.nextLine();
						}*/
						
						validInput = isValidNumber(shapeSize);
					} while (validInput == false);
					
					double radius = Double.parseDouble(shapeSize);
					ShapeMachine = new ShapeMachine(radius);
					ShapeMachine.printInfo();
				
			} else if (menuChoice.equals("Rectangles")) {
				validInput = true;
				System.out.print("Rectangles selected. Please enter the 2 sides:");
					double s1 = 0, s2 = 0;
					
					do {
						boolean v1, v2;
						if (validInput == false) {
							/* if (sc.hasNextLine()) {
								sc.nextLine(); 
							}*/
							System.out.print("#ERROR Negative input. Please input the 2 sides again:");
							
						}
						
						
						shapeSize = sc.nextLine();
						String[] sizes = shapeSize.split(" ");
						// USING ARRAYS TO TAKE IN MORE THAN ONE NUMBER FOR INPUT
						if(sizes.length < 2) {
							validInput = false;
						} else {
							v1 = isValidNumber(sizes[0]);
							v2 = isValidNumber(sizes[1]);
							
							validInput = v1 && v2;
							if (validInput == true) {
								s1 = Double.parseDouble(sizes[0]);
								s2 = Double.parseDouble(sizes[1]);
						
							}
						}
						
					} while (validInput == false);
					
					ShapeMachine = new ShapeMachine(s1, s2);
					ShapeMachine.printInfo();
					
						
					

			} else if (menuChoice.equals("Triangles")) {
				validInput = true;
				System.out.print("Triangles selected. Please enter the 3 sides:");
					
				double s1 = 0, s2 = 0, s3 = 0;
					do {
						boolean v1, v2, v3;
						if (validInput == false) {
							/*if (sc.hasNextLine()) {
								sc.nextLine();
							}*/
							System.out.print("#ERROR Negative input. Please input the 3 sides again:");
						}
						
						
						shapeSize = sc.nextLine();
						String [] sizes = shapeSize.split(" ");
						if (sizes.length < 3) {
							validInput = false;
						
						} else {
							v1 = isValidNumber(sizes[0]);
							v2 = isValidNumber(sizes[1]);
							v3 = isValidNumber(sizes[2]);
							
							validInput = v1 && v2 && v3;
							if(validInput == true) {
								s1 = Double.parseDouble(sizes[0]);
								s2 = Double.parseDouble(sizes[1]);
								s3 = Double.parseDouble(sizes[2]);
										
							}
						}
					} while (validInput == false);
					
					ShapeMachine = new ShapeMachine(s1, s2, s3);
					
					if (ShapeMachine.isTriangleValid() == true) {
						ShapeMachine.printInfo();
					} else {
						System.out.println("#ERROR Triangle is not valid. Returning to menu.");
					}
						
					
			} else {
				System.out.println("#ERROR Invalid option. Please try again.");
			}
		
		} while (exitProgram == false);
		
	
		System.out.print("Terminating program. Have a nice day!");
	}
	
}

// THIS METHOD CALCULATES IF USER INPUT IS A VALID NON NEGATIVE NUMBER
public static boolean isValidNumber(String in) {
	double num = Double.parseDouble(in);
	if (num >= 0) {
		return true;
	}
	return false;
}

//THIS METHOD COMPARES CURRENT DATE TO USER ENTERED DATE
public static boolean isTodayDate(String d, String m, String y) {
	String userEnterDate = d + "-" + m + "-" + y;
	String today = new SimpleDateFormat("dd-MM-yyyy").format(new Date());
	if (userEnterDate.equalsIgnoreCase(today)){
		return true;
	}
	return false;
}

//THIS METHOD DISPLAYS THE MENU
public static void displayMenu() {
	System.out.println("---Welcome to the Shape Machine---");
	System.out.println("Available Options:");
	System.out.println("Circles");
	System.out.println("Rectangles");
	System.out.println("Triangles");
	System.out.println("Exit");
}

private int shapeType;
private double radius;
private double length;
private double width;
private double side1;
private double side2;
private double side3;

// METHOD THAT SETS PARAMETERS FOR CIRCLE
public ShapeMachine(double rad){
	radius = rad;
	shapeType = 1; 
}

// METHOD THAT SETS PARAMETERS FOR RECTANGLE
public ShapeMachine(double l , double w) {
	length = l;
	width = w; 
	shapeType = 2;
	
}

// METHOD THAT SETS PARAMETERS FOR TRIANGLE
public ShapeMachine(double s1, double s2, double s3) {
	side1 = s1;
	side2 = s2;
	side3 = s3;
	shapeType = 3; 
}

// METHOD THAT RETURNS A CIRCLE
public boolean isCircle() {
	return (shapeType == 1);
}

// METHOD THAT RETURNS A RECTANGLE 
public boolean isRectangle() {
	return (shapeType == 2);
}

// METHOD THAT RETURNS A TRIANGLE 
public boolean isTriangle() {
	return (shapeType == 3);
}

//THIS METHOD COMPUTES THE PERIMETER
public double computePerimeter() {
	double res = 0;
	if (isTriangle() == true) {
		res = (double)(side1 + side2 + side3);
		
	} else if (isCircle() == true) {
		res = (double)(Math.PI * radius * 2);
		
	} else if (isRectangle() == true){
		res = (double)(2 * (length + width));
	}
	return res;
	
}

// THIS METHOD COMPUTES THE AREA
public double computeArea() {
	double res = 0;
	if (isTriangle() == true){
		double s = (side1 + side2 + side3)/2.0;
		double x = (s * (s-side1) * (s-side2) * (s-side3));
		double area = Math.sqrt(x);
		res = (double)(area);
	
	} else if (isCircle() == true) {
		res = (double)(Math.PI * radius * radius);
	
	} else if (isRectangle() == true) {
		res = (double)(length * width);
	}

	return res;
}

// THIS METHOD CALCULATES NUMBER OF DIGITS IN AREA AND PERIMETER
public int calculatePercentage(double number){
	String numOfDigits = String.valueOf(number);
	return (numOfDigits.length()-1);
}

//THIS METHOD IDENTIFIES THE TRIANGLE TYPE
public String getTriangleType() {
	String type = "";
	if (isTriangle()) {
		if ((side1 == side2) && (side2 == side3)) {
			type = "Equilateral";
		} else if ((side1 == side2) || (side1 == side3) || (side2 == side3)) {
			type = "Isosceles";
		} else if (!(side1 == side2) || !(side1 == side3) || !(side2 == side3)){
			type = "Scalene"; 
		}
	} 
	return type;
}

//THIS METHOD PRINTS OUT INFO ABOUT THE SHAPE
public void printInfo () {
  String print = "";
  double perimeter = computePerimeter(); 
  double area = computeArea();
  String typeTriangle = getTriangleType();
  
  if (isCircle() == true) {
	  print += "The circumference is: " + perimeter + "\n";
	  print += "The area is: " + area + "\n";
	  print += "Total number of digits in the circumference is: " + calculatePercentage(perimeter) + "\n";
	  print += "Total number of digits in the area is: " + calculatePercentage(area) + "\n";
	  
	  } else if (isRectangle() == true) {
		  print += "The area is: " + area + "\n";
		  print += "The perimeter is: " + perimeter + "\n";
		  print += "Total number of digits in the area is: " + calculatePercentage(area) + "\n";
		  print += "Total number of digits in the perimeter is: " + calculatePercentage(perimeter) + "\n";
	  
	  } else if (isTriangle() == true){
		  print += "The triangle is: " + typeTriangle + "\n";
		  print += "The perimeter is: " + perimeter + "\n";
		  print += "The area is: " + area + "\n";
		  print += "Total number of digits in the perimeter is: " + calculatePercentage(perimeter) + "\n";
		  print += "Total number of digits in the area is: " + calculatePercentage(area) + "\n";
		  
		  
	  }
  	System.out.println(print);
}

//THIS METHOD CHECKS IF USER TRIANGLE IS A VALID TRIANGLE
public boolean isTriangleValid() {
if ((side1 + side2) > side3 && (side1 + side3) > side2 && (side2 + side3 > side1)) {
	return true; 
}
	return false;
}

}
		



