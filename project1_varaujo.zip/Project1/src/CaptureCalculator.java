/*
 Name: Vanessa Araujo
 UFID: 93119166
 Section: 9509
 Instructor: Bryan Taylor
 Brief Description: This program calculates the possibility of a player capturing a monster based on their latitude and longitude of both the player and monster and taking into account their walking and disappearing speeds.
  */
import java.util.Scanner;
import java.lang.Math;
public class CaptureCalculator {

public static void main (String[]args) {
	
Scanner console = new Scanner(System.in);

System.out.println("Hello and welcome to the Monster Capture Possibility Calculator. ");

System.out.println("Please enter the latitude of the monster (1-10):");
int monsterLatitude = console.nextInt();

System.out.println("Please enter the longitude of the monster (1-10):");
int monsterLongitude = console.nextInt();

System.out.println("Please enter the time of the monster appear (1-1440):");
int monsterTa = console.nextInt();

System.out.println("Please enter the possible time of the monster will exist (10-59):");
int monsterTe = console.nextInt();

System.out.println("Please enter the player's ID (8 digits):");
int playerID = console.nextInt();

System.out.println("Please enter the time of the player noticing monster (1-1440 and greater than the time the monster appears):");
int playerNotice = console.nextInt();

System.out.println("Please enter the latitude of the player (1-10)");
int playerLat = console.nextInt();

System.out.println("Please eneter the longitude of the player (1-10):");
int playerLong = console.nextInt();

System.out.println("Please enter the player's walking speed (10-200)");
int playerSpeed = console.nextInt();

int playerLastDigits;
boolean luckyOrNormal = false;

// the boolean will be used to determine wether the player is on lucky or normal list.

playerLastDigits = playerID % 100;

if(playerLastDigits >= 00 && playerLastDigits <= 49){
	luckyOrNormal = true; 
}
else if(playerLastDigits >= 50 && playerLastDigits <= 99){
	luckyOrNormal = false; 
}

double distance = 1000 * Math.sqrt(Math.pow(monsterLatitude - playerLat, 2) + (Math.pow((monsterLongitude - playerLong) ,2)));
double roundedDistance = Math.round(distance*10)/10.0;
double tg = playerNotice + (distance / playerSpeed);
double roundedTg = Math.round(tg*10)/10.0;
int monsterDisappear = (monsterTa + monsterTe);

// the calculations for distance between monster and player, player notice time are rounded to be accurate to a decimal point.

if(luckyOrNormal){
	if(roundedTg <= monsterTa + monsterTe){
    System.out.println("Player " + playerID + " who is on the lucky list, noticed the monster at time " + playerNotice + ", is " + roundedDistance + " m away from the monster, and will arrive at time " + roundedTg + ". The monster's dissapear time is about " + monsterDisappear + ". So the player will capture this monster with definitely possibility. ");
	}
	else if(roundedTg > monsterTa + monsterTe){
		if((roundedTg - (monsterTa + monsterTe)) / monsterTe * 100 >= 0 && (roundedTg - (monsterTa + monsterTe)) / monsterTe * 100 <= 10 ){
			System.out.println("Player " + playerID + " who is on the lucky list, noticed the monster at time " + playerNotice + ", is " + roundedDistance + " m away from the monster, and will arrive at time " + roundedTg + ". The monster's dissapear time is about " + monsterDisappear + ". So the player will capture this monster with highly likely possibility. "); 
		}

		else if((roundedTg - (monsterTa + monsterTe)) / monsterTe * 100 >= 10 && (roundedTg - (monsterTa + monsterTe)) / monsterTe * 100 <= 30){
			System.out.println("Player " + playerID + " who is on the lucky list, noticed the monster at time " + playerNotice + ", is " + roundedDistance + " m away from the monster, and will arrive at time " + roundedTg + ". The monster's dissapear time is about " + monsterDisappear + ". So the player will capture this monster with likely possibility. ");
		}
	
		else if((roundedTg - (monsterTa + monsterTe)) / monsterTe * 100 >= 30 && (roundedTg - (monsterTa + monsterTe)) / monsterTe * 100 <= 40){
			System.out.println("Player " + playerID + " who is on the lucky list, noticed the monster at time " + playerNotice + " , is " + roundedDistance + " m away from the monster, and will arrive at time " + roundedTg + ". The monster's dissapear time is about " + monsterDisappear + ". So the player will capture this monster with unsure possibility. ");
		}
	
		else if ((roundedTg - (monsterTa + monsterTe)) / monsterTe * 100 >= 40 && (roundedTg - (monsterTa + monsterTe))/ monsterTe * 100 <= 50){
			System.out.println("Player " + playerID + " who is on the lucky list, noticed the monster at time " + playerNotice + ", is " + roundedDistance + " m away from the monster, and will arrive at time " + roundedTg + ". The monster's dissapear time is about " + monsterDisappear + ". So the player will capture this monster with unlikely possibility. ");
		}
	
		else if ((roundedTg - (monsterTa + monsterTe)) / monsterTe * 100 >= 50){
			System.out.println("Player " + playerID + " who is on the lucky list, noticed the monster at time " + playerNotice + ", is " + roundedDistance + " m away from the monster, and will arrive at time " + roundedTg + ". The monster's dissapear time is about " + monsterDisappear + ". So the player will capture this monster with highly unlikely possibility. ");
		}
	}
}
	
	
else {
	if(roundedTg <= monsterTa + monsterTe){
	    System.out.println("Player " + playerID + " who is on the normal list, noticed the monster at time " + playerNotice + ", is " + roundedDistance + " m away from the monster, and will arrive at time " + roundedTg + ". The monster's dissapear time is about " + monsterDisappear + ". So the player will capture this monster with definitely possibility. ");
		}
	else if(roundedTg > monsterTa + monsterTe){
		if((roundedTg - (monsterTa + monsterTe)) / monsterTe * 100 >= 0 && (roundedTg - (monsterTa + monsterTe)) / monsterTe * 100 <= 5 ){
			System.out.println("Player " + playerID + " who is on the normal list, noticed the monster at time " + playerNotice + ", is " + roundedDistance + " m away from the monster, and will arrive at time " + roundedTg + ". The monster's dissapear time is about " + monsterDisappear + ". So the player will capture this monster with highly likely possibility. "); 
			}

		else if((roundedTg - (monsterTa + monsterTe)) / monsterTe * 100 >= 5 && (roundedTg - (monsterTa + monsterTe)) / monsterTe * 100 <= 20){
			System.out.println("Player " + playerID + " who is on the normal list, noticed the monster at time " + playerNotice + ", is " + roundedDistance + " m away from the monster, and will arrive at time " + roundedTg + ". The monster's dissapear time is about " + monsterDisappear + ". So the player will capture this monster with likely possibility. ");
		}
		
		else if((roundedTg - (monsterTa + monsterTe)) / monsterTe * 100 >= 20 && (roundedTg - (monsterTa + monsterTe)) / monsterTe * 100 <= 35){
			System.out.println("Player " + playerID + " who is on the normal list, noticed the monster at time " + playerNotice + ", is " + roundedDistance + " m away from the monster, and will arrive at time " + roundedTg + ". The monster's dissapear time is about " + monsterDisappear + ". So the player will capture this monster with unsure possibility. ");
		}
		
		else if ((roundedTg - (monsterTa + monsterTe)) / monsterTe * 100 >= 35 && (roundedTg - (monsterTa + monsterTe))/ monsterTe * 100 <= 40){
			System.out.println("Player " + playerID + " who is on the normal list, noticed the monster at time " + playerNotice + ", is " + roundedDistance + " m away from the monster, and will arrive at time " + roundedTg + ". The monster's dissapear time is about " + monsterDisappear + ". So the player will capture this monster with unlikely possibility. ");
		}
		
		else if ((roundedTg - (monsterTa + monsterTe)) / monsterTe * 100 >= 40){
			System.out.println("Player " + playerID + " who is on the normal list, noticed the monster at time " + playerNotice + ", is " + roundedDistance + " m away from the monster, and will arrive at time " + roundedTg + ". The monster's dissapear time is about " + monsterDisappear + ". So the player will capture this monster with highly unlikely possibility. ");
		}
		
	}


}
// The lines of code above output to the player their likelihood of catching the monster.		
	


}

}

